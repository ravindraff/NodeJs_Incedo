https://stackabuse.com/guide-to-handlebars-templating-engine-for-node/

https://jasonwatmore.com/post/2019/07/18/react-node-server-side-pagination-tutorial-example