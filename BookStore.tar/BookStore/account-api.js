const express = require("express");
const cors = require("cors");

const app = express()

const port = 3331

//GET POST PUT DELETE 
let accountsArray = [{
    "AccountID" : "1",
    "CustomerName" : "Maniac",
    "Balance" : "10000",
    "custAddress" : "Delhi",
    "custPhone" : "1234567890",
},{
    "AccountID" : "2",
    "CustomerName" : "Maniacy",
    "Balance" : "100000",
    "custAddress" : "Lucknow",
    "custPhone" : "1234567890",
},{
    "AccountID" : "3",
    "CustomerName" : "Maniaci",
    "Balance" : "1000000",
    "custAddress" : "Chennai",
    "custPhone" : "1234567890",
}]

var allowCrossDomain = function(req, res, next) {
    // * for allowing everyone to access and share
    res.header("Access-Control-Allow-Origin", "*");

    //Specifying the methods allowed to be performed
    res.header("Access-Control-Allow-Methods", "GET,PUT,POST,DELETE");

    //Content-Type: application/json; charset=utf-8
    res.header("Access-Control-Allow-Header", "Content-Type");
    next();
}

app.use(cors());
app.use(allowCrossDomain);
app.use(express.urlencoded( {extended: false} ));
app.use(express.json());

app.get("/accountsUrl", (req, res) => {
    res.json(accountsArray);
})

//----------------------------------------------------
//Executing all the HTTP verbs

//[GET]
app.get('/accountsUrl/:AccountID', (req, res) => {

    //reading AccountID from the URL
    const AccountID = req.params.AccountID;

    //searching accounts for the AccountID
    for( let Account of accountsArray ) {
        if (Account.AccountID === AccountID) {
            res.json(Account);
            return;
        }
    }

    //sending 404 when not found something : it is a good practice
    res.status(404).send('Account is not there in Database!');
})

//[POST]
app.post('/accountsUrl', (req, res) => {
    //fetching data from the request
    const Account = req.body;
    
    //pushing in API
    accountsArray.push(Account);

    res.send('User Account added to the DataBase');
})

app.get('/accountsUrl', (req, res) => {
    res.json(accountsArray);
})

//[PUT]
app.put('/accountsUrl/:AccountID', (req, res) => {
    //reading AccountID from the URL
    const AccountID = req.params.AccountID;
    const newAccount = req.body;

    //remove item from the accounts array
    for (let i = 0; i<accountsArray.length; i++) {
        let Account = accountsArray[i];

        if(Account.AccountID === AccountID) {
            accountsArray[i] = newAccount
        }
    }

    //sending the status code 404 when not found 
    res.send('Account is updated');
})

//[DELETE]
app.delete('/accountsUrl/:AccountID', (req, res) => {
    //reading AccountID from the URL
    const AccountID = req.params.AccountID;

    //remove AccountID from the accounts array
    // use any method filter(), splice(), looping method
    accountsArray = accountsArray.filter( p => {
        if (p.AccountID !== AccountID) {
            return true                     //select all the unmatched values and filters them out
        }
        else 
            return false                    //doesn't copy or skips the value matched (indirectly delete)
    }) 
    
    //sending  404 when not found is a good practice
    res.send('Account removed from database!')
})


app.listen(port, () => console.log(`Account Application is listening on port ${port}`))
