// import logo from './logo.svg';
import './App.css';
// import AddCourse from './components/AddCourse';
import Badge from './components/Badge';
import BadgeWithClass from './components/BadgeWithClass';
import Dropdown from './components/Dropdown';
import ViewCourses from './components/ViewCourses';
import ViewCoursesWithClass from './components/ViewCoursesWithClass';
// import Quiz from './components/Quiz';

function App() {
  return (
    <div>
      {/* <Badge caption="Inbox"></Badge>
      <hr/>
      <BadgeWithClass caption="Sent"></BadgeWithClass>
      <hr/>
      <Dropdown></Dropdown>
      <hr/> */}
    {/* <AddCourse></AddCourse> */}
    {/* <ViewCourses></ViewCourses>
     */}
     {/* <ViewCoursesWithClass></ViewCoursesWithClass> */}
     <ViewCourses></ViewCourses>
     
    </div>
  );
}

export default App;
