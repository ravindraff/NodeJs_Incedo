export const FETCH_QUESTIONS = "FETCH_QUESTIONS";
export const INCREMENT_CURRENT_QUESTION = "INCREMENT_CURRENT_QUESTION";

export const fetchQuestions = () => {
  return (dispatch) => {
    //TODO:1.Fetch the data from the server
    //     2.Dispatch the fetched data to the reducer
  };
};

export const incrementCurrentQuestion = (isCorrect) => {
  return;
  //TODO:Dispatch an action to the reducer
};
