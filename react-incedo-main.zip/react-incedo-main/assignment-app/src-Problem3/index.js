import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";




//TODO:Create Store with Thunk middleware
ReactDOM.render(
 //TODO:Provide Store to the app
    <App />
  
  document.getElementById("root")
);

reportWebVitals();
