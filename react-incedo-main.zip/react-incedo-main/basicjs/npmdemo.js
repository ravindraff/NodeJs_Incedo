// core library in nodejs
const fs = require('fs');

// external library -- explicit install
const react = require('react');