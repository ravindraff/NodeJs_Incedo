import logo from "./logo.svg";
import "./App.css";
import Dropdown from "./Dropdown";

function App() {
  return <Dropdown />;
}

export default App;
