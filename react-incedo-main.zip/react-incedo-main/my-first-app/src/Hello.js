// Hello component
function Hello(){
    return(
        <h2>Hello Component</h2>
    )

}

export default Hello;